import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Dashboard() {
  const [stores, setStores] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    axios.get('http://localhost:5000/api/user/stores').then(res => {
      setStores(res.data);
    });
  }, []);

  const submitRating = async (storeId, rating) => {
    await axios.post('http://localhost:5000/api/user/rate', {
      user_id: user.id,
      store_id: storeId,
      rating: parseInt(rating)
    });
    alert('Rating submitted!');
  };

  return (
    <div>
      <h2>Welcome, {user.name}</h2>
      <h3>Store List</h3>
      {stores.map(store => (
        <div key={store.id}>
          <h4>{store.name}</h4>
          <p>{store.address}</p>
          <input type='number' min='1' max='5' onChange={e => submitRating(store.id, e.target.value)} placeholder='Rate 1-5' />
        </div>
      ))}
    </div>
  );
}
