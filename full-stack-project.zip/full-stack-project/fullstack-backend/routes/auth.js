const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config');
const router = express.Router();

router.post('/signup', async (req, res) => {
  const { name, email, address, password, role } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  try {
    const user = await pool.query(
      'INSERT INTO users(name, email, address, password, role) VALUES($1, $2, $3, $4, $5) RETURNING *',
      [name, email, address, hashed, role || 'user']
    );
    res.json(user.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Email already used' });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  console.log("email "+email + " password" +password)
  const userRes = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
  if (userRes.rowCount === 0) return res.status(401).json({ error: 'Invalid' });
  const user = userRes.rows[0];
  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(401).json({ error: 'Invalid' });
  const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET);
  res.json({ token, user });
});

module.exports = router;
