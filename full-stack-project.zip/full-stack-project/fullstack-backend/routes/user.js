const express = require('express');
const pool = require('../config');
const router = express.Router();

router.get('/stores', async (req, res) => {
  const result = await pool.query('SELECT * FROM stores');
  res.json(result.rows);
});

router.post('/rate', async (req, res) => {
  const { user_id, store_id, rating } = req.body;
  try {
    await pool.query(
      'INSERT INTO ratings(user_id, store_id, rating) VALUES($1, $2, $3) ON CONFLICT(user_id, store_id) DO UPDATE SET rating = $3',
      [user_id, store_id, rating]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Could not submit rating' });
  }
});

module.exports = router;
