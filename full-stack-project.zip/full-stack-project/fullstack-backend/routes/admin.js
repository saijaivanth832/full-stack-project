const express = require('express');
const pool = require('../config');
const router = express.Router();

router.get('/dashboard', async (req, res) => {
  try {
    const users = await pool.query('SELECT COUNT(*) FROM users');
    const stores = await pool.query('SELECT COUNT(*) FROM stores');
    const ratings = await pool.query('SELECT COUNT(*) FROM ratings');
    res.json({
      users: users.rows[0].count,
      stores: stores.rows[0].count,
      ratings: ratings.rows[0].count
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
