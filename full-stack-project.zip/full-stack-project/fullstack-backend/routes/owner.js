const express = require('express');
const pool = require('../config');
const router = express.Router();

router.get('/ratings/:ownerId', async (req, res) => {
  const ownerId = req.params.ownerId;
  try {
    const result = await pool.query(
      `SELECT r.rating, u.name FROM ratings r
       JOIN users u ON r.user_id = u.id
       JOIN stores s ON r.store_id = s.id
       WHERE s.owner_id = $1`, [ownerId]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Error fetching ratings' });
  }
});

module.exports = router;
